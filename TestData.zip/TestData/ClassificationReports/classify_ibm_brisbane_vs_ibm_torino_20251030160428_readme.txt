Devices: ibm_brisbane vs ibm_torino
Samples: 50 | Features per sample: 40 | Circuits: 8
Circuits used:
 - cross_talk
 - entangler_chain
 - extra_rand_10
 - extra_rand_11
 - interleaved_x
 - pm
 - rand_rot
 - spin_echo

Summary (per model):
             model  splits  acc_mean  acc_std  auc_mean  auc_std  precision_macro_mean  recall_macro_mean  f1_macro_mean
NearestCentroid_L1       6  0.942130 0.086520  0.937500 0.095470              0.959524           0.937500       0.937169
       RF_baseline       6  0.902778 0.119477  0.970833 0.046585              0.935417           0.895833       0.888441
         LogReg_L2       6  0.881944 0.064525  0.908333 0.079604              0.912302           0.875000       0.875361

Per-split metrics (first rows):
             model  split      acc    auc  precision_macro  recall_macro  f1_macro  threshold_used
         LogReg_L2      1 0.777778 0.7500         0.857143         0.750  0.750000             0.5
         LogReg_L2      2 0.888889 0.9500         0.916667         0.875  0.883117             0.5
         LogReg_L2      3 0.875000 0.8750         0.900000         0.875  0.873016             0.5
         LogReg_L2      4 1.000000 1.0000         1.000000         1.000  1.000000             0.5
         LogReg_L2      5 0.875000 0.9375         0.900000         0.875  0.873016             0.5
         LogReg_L2      6 0.875000 0.9375         0.900000         0.875  0.873016             0.5
NearestCentroid_L1      1 0.777778 0.7500         0.857143         0.750  0.750000             NaN
NearestCentroid_L1      2 1.000000 1.0000         1.000000         1.000  1.000000             NaN
NearestCentroid_L1      3 1.000000 1.0000         1.000000         1.000  1.000000             NaN
NearestCentroid_L1      4 1.000000 1.0000         1.000000         1.000  1.000000             NaN
NearestCentroid_L1      5 0.875000 0.8750         0.900000         0.875  0.873016             NaN
NearestCentroid_L1      6 1.000000 1.0000         1.000000         1.000  1.000000             NaN

Permutation test (NearestCentroid_L1 pipeline): true_acc=0.942, p-value=0.0010

Options: opt_threshold=none, repeats=1, class_weight=none, rf_depth=auto, rf_leaf=2
